# FaithFest

FaithFest is a database-backed cultural heritage explorer for Hinduism, Islam, and Christianity. It provides religion and festival discovery, detailed festival profiles, search/filtering, a dynamic calendar, regional information, learning mode, quizzes, favorites, reminders, voice narration, comparison, admin content management, references, and a PWA-ready frontend.

## Requirements
- Node.js 22.5+ (uses the built-in `node:sqlite` module)

## Run
```bash
npm start
```
Open http://localhost:3000

## Demo accounts
- User: `demo@faithfest.local` / `Demo@12345`
- Admin: `admin@faithfest.local` / `Admin@12345`

Change these passwords before any real deployment.

## Notes
- SQLite is used locally so the project runs without external credentials. The data layer is isolated in `db.js`, making migration to Supabase/PostgreSQL straightforward.
- AI is intentionally not faked. Configure `AI_API_URL` and `AI_API_KEY` for a real server-side AI provider; otherwise the assistant reports that it is not configured.
- Seed content is explicitly marked as development/demo content and includes source references. Review/expand it before academic/public deployment.
- Media can be added by an admin. Do not upload copyrighted material without permission.
